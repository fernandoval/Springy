<?php

namespace Browser;

require_once __DIR__.'/../src/Browser/Autoloader.php';
Autoloader::register();
